package model;

import java.util.Hashtable;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;

@Singleton
public class UserDB {

	Hashtable<String, String> authorizedUsers = new Hashtable<String, String>();

	public UserDB() {
	}

	@PostConstruct
	private void init() {
		authorizedUsers.put("edu", "1234");
		authorizedUsers.put("sebas", "1234");
	}

	public Hashtable<String, String> getAuthorizedUsers() {
		return authorizedUsers;
	}

	public void setAuthorizedUsers(Hashtable<String, String> authorizedUsers) {
		this.authorizedUsers = authorizedUsers;
	}

}
