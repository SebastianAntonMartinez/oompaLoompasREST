package model;


import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;

@Singleton
public class DilbertSaysManager {

	@EJB
	private DilbertSaysDB DilDb;
	private int rn;
	private String[] says;

	
	public DilbertSaysManager(){}
	
	@PostConstruct
	private void init()
	{
	
	}

	public String getRandomSay() 
	{
		says = DilDb.getSays();
		this.rn =(int)(this.rn+1)%4;
		return says[rn];
	}
}
