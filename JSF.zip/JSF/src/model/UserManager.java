package model;

import java.util.Hashtable;

import javax.ejb.EJB;
import javax.ejb.Singleton;

@Singleton
public class UserManager {

	@EJB
	private UserDB DB;

	public UserManager() {
	}

	public boolean isARegisteredUser(String usr, String pass) {

		Hashtable<String, String> tab = DB.getAuthorizedUsers();

		if (tab.get(usr) != null) {
			if (tab.get(usr).equals(pass)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}

	}

}
