package controller;


import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import model.DilbertSaysManager;
import view.UserLoginBean;

@ManagedBean(name="dilbertController")
public class DilbertSaysController {
	
	@ManagedProperty("#{userView}")
	private UserLoginBean usuari;
	
	@EJB
	private DilbertSaysManager DilMg;
	
	private static String notAllowedMessage = "Bye bye, you are not registered";
	
	public DilbertSaysController(){}
	
	public UserLoginBean getUsuari() {
		return usuari;
	}

	public void setUsuari(UserLoginBean usuari) {
		this.usuari = usuari;
	}

	public DilbertSaysManager getDilMg() {
		return DilMg;
	}

	public void setDilMg(DilbertSaysManager dilMg) {
		DilMg = dilMg;
	}

	public static String getNotAllowedMessage() {
		return notAllowedMessage;
	}

	public static void setNotAllowedMessage(String notAllowedMessage) {
		DilbertSaysController.notAllowedMessage = notAllowedMessage;
	}

	public String getRandomSay()
	{
		//Si l'usuari esta loguejat es retornen les dites, sino et diu que et tornis a loguejar
		if (usuari.isLogged()){
			return DilMg.getRandomSay();
		}else{
			return notAllowedMessage;
		}
		
	}

}
