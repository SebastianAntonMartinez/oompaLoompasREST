package controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import view.UserLoginBean;
import model.UserManager;

@ManagedBean (name="userController")
public class UserLoginController {
	
	
	@ManagedProperty("#{userView}")
	private UserLoginBean usuari;
	
	public UserManager getUsrmg() {
		return usrmg;
	}

	public void setUsrmg(UserManager usrmg) {
		this.usrmg = usrmg;
	}


	@EJB
	private UserManager usrmg;
	
	public UserLoginController(){}
	
	public UserLoginBean getUsuari() {
		return usuari;
	}

	public void setUsuari(UserLoginBean usuari) {
		this.usuari = usuari;
	}
	
	public String loginUser(){
		
		boolean log = usrmg.isARegisteredUser(this.usuari.getLogin(), this.usuari.getPasswd());
		
		this.usuari.setLogged(log);
		if ( log == true)
		{			
			return "welcome.xhtml";
		}
		else
		{
			return "notLogged.xhtml";
		}
				
	}
	
	public String logout(){
		this.usuari.setLogged(false);
		return "index.xhtml";
	}

	
}
